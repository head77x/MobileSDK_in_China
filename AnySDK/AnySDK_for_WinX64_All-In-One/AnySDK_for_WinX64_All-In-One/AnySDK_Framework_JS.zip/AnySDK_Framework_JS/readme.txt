AnySDK Framework_2.0.5
lua-bindings_1.0beta

sample：
https://github.com/shujunqiao/anysdk-Lua-sample

v1.0beta  -- 2014.07.18
新增库：
1、支持anysdk的lua绑定。
