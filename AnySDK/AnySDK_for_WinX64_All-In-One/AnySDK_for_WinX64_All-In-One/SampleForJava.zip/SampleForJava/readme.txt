Sample_v0.9 for AnySDK_Framework_Java v0.9

v0.9_beta 2014.7.18
