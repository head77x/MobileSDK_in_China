package cn.play.egamesmsonline;

import java.util.Random;

import cn.egame.terminal.egameforonlinegame.EgameFee;
import cn.egame.terminal.egameforonlinegame.EgameFeeResultListener;
import cn.egame.terminal.smspay.EgamePayListener;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
	Activity thisActivity;
	Button button1, button2;
	int fee;
	String serialNo;
	Random Rnd=new Random();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		thisActivity = this;

		button1 = (Button) findViewById(R.id.button1);
		button2 = (Button) findViewById(R.id.button2);
		
		button1.setOnClickListener(button1_OnClickListener);
		button2.setOnClickListener(button2_OnClickListener);
	}

	private OnClickListener button1_OnClickListener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			fee = 1;// 支付金额1元钱。
			serialNo = "20131206demo"+Rnd.nextInt(1000);// 交易号最长32位长度。
			EgameFee.payBySms(thisActivity, fee, serialNo, true,
					feeResultListener);
		}
	};

	private OnClickListener button2_OnClickListener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			fee = 1;// 支付金额24元钱。
			serialNo = "20131206demo"+Rnd.nextInt(1000);// 交易号最长32位长度。
			EgameFee.pay(thisActivity, fee, serialNo, feeResultListener);

		}
	};

	private EgameFeeResultListener feeResultListener = new EgameFeeResultListener() {
		@Override
		public void egameFeeSucceed(String arg0, int arg1, String arg2) {
			// TODO Auto-generated method stub
			Toast.makeText(thisActivity, "计费请求发送成功", Toast.LENGTH_LONG).show();
		}

		@Override
		public void egameFeeFailed(int arg0) {
			Toast.makeText(thisActivity, "计费请求发送失败", Toast.LENGTH_LONG).show();

		}

		@Override
		public void egameFeeCancel() {
			Toast.makeText(thisActivity, "计费请求已取消", Toast.LENGTH_LONG).show();

		}
	};

}
