/** Automatically generated file. DO NOT MODIFY */
package cn.play.egamesmsonline;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}